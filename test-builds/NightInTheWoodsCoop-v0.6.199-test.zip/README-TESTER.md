# Night in the Woods Co-op — v0.6.199 test build

This is an experimental same-PC-tested prototype, not a supported or verified release. The two-machine/LAN setup below has **not** been tested. It may fail or behave unexpectedly; back up anything you care about before trying it.

This bundle contains only two co-op DLLs, two configuration examples, and these instructions. It does not include Night in the Woods, BepInEx, game assets, saves, or logs. Each player must install and own their own Windows x64 Steam copy of Night in the Woods. The tested game build is Steam AppID 481510, build 5940043.

## Requirements

- Night in the Woods, Windows x64 Steam build 5940043 on both computers.
- BepInEx 5.4.23.5, Windows x64 Mono build, installed separately from the official [BepInEx v5.4.23.5 release](https://github.com/BepInEx/BepInEx/releases/tag/v5.4.23.5). Do not use BepInEx 6 for this test.
- Two computers that can reach each other over IPv4 UDP. Same-LAN play is the intended first attempt; LAN play has not yet been verified. Internet/port-forwarding play is also unverified.

## Install on both computers

1. Exit the game.
2. Install BepInEx into the game's root folder using its Windows x64 Mono archive. The game root is the folder containing `Night in the Woods.exe`. Launch the game once, then exit, so BepInEx creates its folders.
3. Copy the `BepInEx` folder from this zip into that game root and merge folders. This adds `NightInTheWoodsCoop.dll` under `BepInEx/plugins` and `NightInTheWoodsSavePathPatcher.dll` under `BepInEx/patchers`.
4. Choose the host or client example from `templates`. Copy the chosen file into `BepInEx/config` and rename it exactly `coop-anything.nitw.cfg`.
5. Keep the same UDP port on both computers. These examples use port `52000`.

## Configure the connection

- Host computer: use `Host-coop-anything.nitw.cfg`. Leave `Role = Host`.
- Friend's computer: use `Client-coop-anything.nitw.cfg`. Change `HostAddress = CHANGE_ME` to the host computer's private IPv4 address (for example, the IPv4 shown for the active Wi-Fi/Ethernet adapter by `ipconfig`). Leave `Role = Client`.
- If Windows Firewall asks, allow the game on the private network. The host may need an inbound UDP rule for port 52000. Do not expose the port to the public internet for this unverified test.
- Start the host game first, then the client game. Each person should use their own Steam account and game installation.

## Saves and safety

The included save-path patcher redirects the game's save lookups to `BepInEx/config/NightInTheWoodsCoop/Saves` inside that game folder. Modded sessions therefore use a separate save folder; existing Steam saves are not imported into this location. To go back to normal, exit the game and remove both co-op DLLs. Keep the separate save folder if you want to preserve this test session.

## What has actually been tested

v0.6.199 was loaded in two isolated copies on one PC over loopback. Bot-driven tests verified remote Mae movement/presentation, selected dialogue and story-variable synchronization, and one guest-origin SceneLink transition. The latest Ravine bot session kept both peers connected and hash-matched. This does **not** verify two computers, LAN/firewall behavior, normal keyboard controls, save/restart behavior, or a full playthrough. The Creek hotspot worked from the host; guest-origin interaction at that one-time prompt was not conclusive because the host had already used it.

The public source repository currently describes candidate v0.6.197. This test ZIP contains the locally runtime-tested v0.6.199 binaries, so the public source does not exactly match the packaged build. Source and project notes: https://github.com/SamuelAustin2001/night-in-the-woods-coop

If it fails, stop both games and send the error text plus the relevant BepInEx log after reviewing it for your Windows username or other private paths. Avoid posting full logs publicly without redacting those paths.
